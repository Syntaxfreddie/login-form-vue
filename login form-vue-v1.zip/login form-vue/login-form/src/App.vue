<template>
     <signupForm/>
</template>

<script>
import signupForm from './components/signupform.vue';
export default {
  name: "App",
  components: { signupForm }

}
</script>

<style>
#app {
  font-family: Arial, Helvetica, sans-serif;
  -webkit-font-smoothing: antialiased;
  -moz-osx-font-smoothing: grayscale;
  text-align: center;
  color: #030e1a;
  /* margin-left: 32%; */
  padding: 0;
  margin: 60px 480px;
}

body {
  margin: 0;
    /* color: #820816; */
  background: white;
}


</style>
