<template>
<form>
    <label>email:</label>
    <input type="email" required v-model="email">

    <label>password:</label>
    <input type="password" required v-model="password">

    <label>Gender:</label>
    <select v-model="Gender">
        <option value="Male">Male</option>
        <option value="Female">Female</option>
    </select>

    <div class="terms">
        <input type="checkbox" v-model="terms" required>
        <label>Accept terms and conditions</label>
    </div>
</form> 
<br>
<!-- <p>Email: {{ email }}</p> <br>
<p>Password:{{ password }}</p><br>
<p>Gender:{{ Gender }}</p><br>
<p>Terms:{{ terms }}</p> -->

</template>

<script>
export default{
    data(){
        return{
            email: "",
            password: "",
            Gender: "Male",
            terms: false
        }
    }

}
</script>

<style>
form{
    min-width: 550px;
    margin: 30px auto;
    background: rgb(233, 233, 236);
    text-align: left;
    padding: 40px;
    border-radius: 10px;
}
label{
    color: #151212;
    display: inline-block;
    margin: 25px 0 15px;
    font-size: 0.6em;
    text-transform: uppercase;
    letter-spacing: 1px;
    font-weight: bold;
}
input, select{
    display: block;
    padding: 10px 6px;
    width: 100%;
    box-sizing: border-box;
    border: none;
    border-bottom: 1px solid black;
    color: #07011f;
    
}
input[type="checkbox"] {
    display: inline-block;
    width: 17px;
    margin: 0 10px  0 0;
    position: relative;
    top: 2px;
}

</style>